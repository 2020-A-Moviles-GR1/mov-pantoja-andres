package com.example.examencrud.adapters

class CancionAdapter {
}