package com.example.moviles

class RecyclerAdapter(
        private val listaUsuario: List<UsuarioHttp>,
//    private val contexto
        private val recyclerView: RecyclerView
): RecyclerView.Adapter {


}