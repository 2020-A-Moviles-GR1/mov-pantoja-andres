package com.example.moviles

class ServicioBDDMemoria{
    companion object{
        var numero = 100
        fun anadirNumero(){
            numero = numero + 1
        }
    }
}